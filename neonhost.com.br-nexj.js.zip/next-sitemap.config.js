/** @type {import('next-sitemap').IConfig} */

module.exports = {
	siteUrl: "https://neonhost.com.br/",
	generateRobotsTxt: true,
};
