import SobreNosPage from "@/components/sobre-nos-page"

export default function Page() {
  return <SobreNosPage />
}
