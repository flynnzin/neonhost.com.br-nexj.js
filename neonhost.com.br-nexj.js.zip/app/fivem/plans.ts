export const plans = [
  {
    name: "NeonLite",
    price: "96,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-1",
    description: {
      ram: "4GB",
      cores: "3 núcleos",
      ssd: "50GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
  {
    name: "NeonSpeed",
    price: "149,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-2",
    description: {
      ram: "6GB",
      cores: "4 núcleos",
      ssd: "60GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
  {
    name: "NeonForce",
    price: "189,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-3",
    description: {
      ram: "8GB",
      cores: "5 núcleos",
      ssd: "70GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
  {
    name: "NeonStrike",
    price: "239,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-4",
    description: {
      ram: "10GB",
      cores: "7 núcleos",
      ssd: "80GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
  {
    name: "NeonMax",
    price: "289,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-5",
    description: {
      ram: "12GB",
      cores: "8 núcleos",
      ssd: "90GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
  {
    name: "NeonUltra",
    price: "359,90",
    link: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-6",
    description: {
      ram: "16GB",
      cores: "9 núcleos",
      ssd: "100GB",
      attrs: [
        "Anti-DDoS Incluído",
        "Painel de Controle",
        "Suporte 24/7",
        "AMD Ryzen 9",
        "Uptime 99.9%",
        "Incluso NeonShield"
      ],
    },
  },
]
