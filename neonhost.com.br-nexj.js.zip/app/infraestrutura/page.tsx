import InfraestruturaPage from "@/components/infraestrutura-page"

export default function Page() {
  return <InfraestruturaPage />
}
