import AntiDDosPage from "../api/anti-ddos-page"

export default function Page() {
  return <AntiDDosPage />
}
