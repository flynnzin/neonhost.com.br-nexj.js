module.exports = {

"[project]/config/maintenance.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

// Configuração de manutenção para as páginas de jogos
__turbopack_esm__({
    "maintenanceConfig": ()=>maintenanceConfig
});
const maintenanceConfig = {
    // Altere para false quando quiser liberar as páginas de jogos
    isGamesUnderMaintenance: false,
    // Mensagens personalizáveis
    title: "Em Breve",
    subtitle: "Estamos preparando algo incrível para você!",
    description: "Nossa seção de jogos está sendo finalizada com muito carinho. Em breve você terá acesso aos melhores servidores de hospedagem para seus jogos favoritos.",
    // Data estimada de lançamento (opcional)
    estimatedLaunch: "2025",
    // Links de contato
    discordUrl: "https://discord.gg/neonhost",
    supportEmail: "suporte@neonhost.com.br"
};

})()),
"[project]/components/maintenance-page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "MaintenancePage": ()=>MaintenancePage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/arrow-left.js [app-ssr] (ecmascript) <export default as ArrowLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-ssr] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-ssr] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/gamepad-2.js [app-ssr] (ecmascript) <export default as Gamepad2>");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
function MaintenancePage({ title = "Em Breve", subtitle = "Estamos preparando algo incrível para você!", description = "Nossa seção de jogos está sendo finalizada com muito carinho. Em breve você terá acesso aos melhores servidores de hospedagem para seus jogos favoritos.", showBackButton = true, backUrl = "/" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#0A0C10] flex items-center justify-center px-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 pointer-events-none",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/5 rounded-full blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/maintenance-page.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative max-w-4xl mx-auto text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-full border border-purple-500/30 mb-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__["Gamepad2"], {
                            className: "w-12 h-12 text-purple-400"
                        }, void 0, false, {
                            fileName: "[project]/components/maintenance-page.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-5xl md:text-6xl font-bold mb-6 text-white",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-2xl md:text-3xl font-semibold mb-8 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500",
                        children: subtitle
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed",
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-12",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/5 border border-white/10 rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__["Gamepad2"], {
                                            className: "w-6 h-6 text-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/maintenance-page.tsx",
                                            lineNumber: 48,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 47,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold text-white mb-2",
                                        children: "50+ Jogos"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 50,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-400 text-sm",
                                        children: "Minecraft, FiveM, Rust, Palworld e muito mais"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 51,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 46,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/5 border border-white/10 rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                            className: "w-6 h-6 text-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/maintenance-page.tsx",
                                            lineNumber: 56,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 55,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold text-white mb-2",
                                        children: "Lançamento 2025"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 58,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-400 text-sm",
                                        children: "Aguarde novidades em breve"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 59,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 54,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white/5 border border-white/10 rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                                            className: "w-6 h-6 text-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/maintenance-page.tsx",
                                            lineNumber: 64,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 63,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-lg font-semibold text-white mb-2",
                                        children: "Suporte 24/7"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 66,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-400 text-sm",
                                        children: "Equipe especializada sempre disponível"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 67,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 62,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row gap-4 justify-center mb-12",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "https://discord.gg/neonhost",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl font-medium transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 79,
                                        columnNumber: 13
                                    }, this),
                                    "Entrar no Discord"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 73,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "mailto:suporte@neonhost.com.br",
                                className: "bg-white/10 hover:bg-white/20 text-white px-8 py-3 rounded-xl font-medium transition-colors border border-white/10 flex items-center justify-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 87,
                                        columnNumber: 13
                                    }, this),
                                    "Falar com Suporte"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 72,
                        columnNumber: 9
                    }, this),
                    showBackButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: backUrl,
                        className: "inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeft$3e$__["ArrowLeft"], {
                                className: "w-4 h-4"
                            }, void 0, false, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this),
                            "Voltar ao início"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 94,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-16 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-2xl font-bold text-white mb-4",
                                children: "Seja o primeiro a saber!"
                            }, void 0, false, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-400 mb-6",
                                children: "Cadastre-se para receber notificações quando nossa seção de jogos estiver disponível."
                            }, void 0, false, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 106,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-3 max-w-md mx-auto",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "email",
                                        placeholder: "Seu melhor e-mail",
                                        className: "flex-1 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 transition-colors"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 110,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-3 rounded-xl font-medium transition-all duration-300 hover:scale-105",
                                        children: "Notificar-me"
                                    }, void 0, false, {
                                        fileName: "[project]/components/maintenance-page.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/maintenance-page.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/maintenance-page.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/maintenance-page.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/maintenance-page.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}

})()),
"[project]/config/games.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "gamesConfig": ()=>gamesConfig,
    "getDiscountedGames": ()=>getDiscountedGames,
    "getFeaturedGames": ()=>getFeaturedGames,
    "getGameById": ()=>getGameById,
    "getGameCategories": ()=>getGameCategories,
    "getGamesByCategory": ()=>getGamesByCategory,
    "getNewGames": ()=>getNewGames,
    "getPopularGames": ()=>getPopularGames,
    "searchGames": ()=>searchGames
});
const gamesConfig = [
    // MINECRAFT
    {
        id: "minecraft",
        name: "Minecraft",
        slug: "minecraft",
        image: "/games/minecraft.webp",
        logo: "/games/minecraft.webp",
        featuredImage: "/games/minecraft.webp",
        description: "Na NeonHost, oferecemos servidores populares como Vanilla, Forge, Mohist, Paper e Bedrock Edition, além de modpacks como Pixelmon, SkyFactory e RLCraft. Nossos servidores são otimizados para oferecer a melhor experiência de jogo possível.",
        shortDescription: "O jogo de construção mais popular do mundo com mods ilimitados",
        price: 19.9,
        originalPrice: 29.9,
        discount: 34,
        category: "Sandbox",
        rating: 4.9,
        players: "15.2K",
        isPopular: true,
        isFeatured: true,
        paymentLink: "https://app.neonhost.com.br/games/minecraft",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "Xbox",
            "PlayStation",
            "Switch",
            "Mobile"
        ],
        developer: "Mojang Studios",
        features: [
            "Modpacks Automáticos",
            "Backup Diário",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "FTP/SFTP Access",
            "Plugins Ilimitados",
            "Mundos Customizados"
        ],
        minPlayers: 1,
        maxPlayers: 200,
        requirements: {
            ram: "2GB mínimo",
            cpu: "Intel i3 ou AMD equivalente",
            storage: "5GB disponível"
        },
        plans: [
            {
                id: "minecraft-1gb",
                name: "Minecraft - 1GB",
                price: 13.9,
                originalPrice: 29.9,
                players: 5,
                ram: "1GB",
                cpu: "2 vCores",
                storage: "10GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-simples"
            },
            {
                id: "minecraft-3gb",
                name: "Minecraft - 3GB",
                price: 33.9,
                originalPrice: 59.9,
                players: 25,
                ram: "3GB",
                cpu: "4 vCores",
                storage: "25GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-basic"
            },
            {
                id: "minecraft-6gb",
                name: "Minecraft - 6GB",
                price: 49.9,
                originalPrice: 119.9,
                players: 50,
                ram: "6GB",
                cpu: "6 vCores",
                storage: "50GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-advanced"
            },
            {
                id: "minecraft-8gb",
                name: "Minecraft - 8GB",
                price: 77.42,
                originalPrice: 159.9,
                players: 75,
                ram: "6GB",
                cpu: "6 vCores",
                storage: "50GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-pro"
            },
            {
                id: "minecraft-16gb",
                name: "Minecraft - 16GB",
                price: 94.92,
                originalPrice: 182.23,
                players: 100,
                ram: "16GB",
                cpu: "7 vCores",
                storage: "55GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-ultra"
            },
            {
                id: "minecraft-20gb",
                name: "Minecraft - 20GB",
                price: 129.92,
                originalPrice: 210.23,
                players: 125,
                ram: "20GB",
                cpu: "7 vCores",
                storage: "55GB NVMe",
                features: [
                    "Backup Diário",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Modpacks",
                    "Plugins",
                    "FTP Access",
                    "MySQL"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/minecraft/plano-enterprise"
            }
        ],
        faq: [
            {
                question: "Onde estão localizados os servidores?",
                answer: "Nossos servidores estão localizados em São Paulo, Brasil, garantindo baixa latência para jogadores brasileiros."
            },
            {
                question: "Como funciona o reembolso?",
                answer: "Oferecemos reembolso em até 7 dias após a compra, sem perguntas."
            },
            {
                question: "Posso rodar mods?",
                answer: "Sim, todos os nossos planos suportam mods e plugins, exceto o plano Bedrock que é exclusivo para Minecraft Bedrock Edition."
            },
            {
                question: "Posso aumentar meu plano?",
                answer: "Sim, você pode fazer upgrade do seu plano a qualquer momento através do painel de controle."
            }
        ],
        testimonials: [
            {
                title: "NeonHost é incrível",
                author: "Humberto Junior",
                content: "A neonhost é incrível, custo benefício e um belo suporte, tanto pra colocar mods e essas coisas, recomendo e irei utilizar muito",
                rating: 5
            },
            {
                title: "Uso e recomendo",
                author: "Alexandre Denardi",
                content: "Já uso a empresa para hospedar servidores a anos GTA RP, servidores Linux, hoje estou até mesmo com meu banco de dados hospedado, sem quedas e SLA perfeito.",
                rating: 5
            }
        ]
    },
    // PWALWORD
    {
        id: "palworld",
        name: "Palworld",
        slug: "palworld",
        image: "/games/palworld.webp",
        logo: "/games/palworld.webp",
        featuredImage: "/games/palworld.webp",
        description: "Hospede seu próprio servidor de Palworld com a NeonHost. Capture, colecione e batalhe com criaturas em um mundo aberto cheio de aventuras e desafios. Nossos servidores são otimizados para suportar grandes quantidades de jogadores e Pals.",
        shortDescription: "Capture criaturas em um mundo aberto cheio de aventuras",
        price: 79.9,
        originalPrice: 120.0,
        discount: 34,
        category: "Aventura",
        rating: 4.8,
        players: "8.5K",
        isNew: true,
        isPopular: true,
        paymentLink: "https://app.neonhost.com.br/games/palworld",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "Xbox"
        ],
        developer: "Pocketpair",
        features: [
            "Configuração Personalizada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Mods Suportados",
            "Mundo Persistente",
            "PvP/PvE Configurável"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "8GB disponível"
        },
        plans: [
            {
                id: "palworld-6gb",
                name: "Palworld 6GB",
                price: 69.9,
                originalPrice: 120.0,
                players: 10,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "35GB NVMe",
                features: [
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Mods",
                    "Configuração Avançada",
                    "FTP Access",
                    "Base Dedicada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/palworld/palworld-6gb"
            },
            {
                id: "palworld-10gb",
                name: "Palworld 10GB",
                price: 109.9,
                originalPrice: 199.9,
                players: 20,
                ram: "10GB",
                cpu: "6 vCores",
                storage: "50GB NVMe",
                features: [
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Mods",
                    "Configuração Avançada",
                    "FTP Access",
                    "Base Dedicada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/palworld/palworld-10gb"
            },
            {
                id: "palworld-pro",
                name: "Palworld 14GB",
                price: 149.9,
                originalPrice: 223.9,
                players: 32,
                ram: "14GB",
                cpu: "8 vCores",
                storage: "75GB NVMe",
                features: [
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Painel Web",
                    "Mods",
                    "Configuração Avançada",
                    "FTP Access",
                    "Base Dedicada"
                ],
                paymentLink: "https://app.neonhost.com.br/checkout/palworld-pro"
            }
        ],
        faq: [
            {
                question: "Quantos jogadores o servidor suporta?",
                answer: "Depende do plano escolhido, mas nossos servidores de Palworld suportam de 10 a 32 jogadores simultâneos."
            },
            {
                question: "Posso instalar mods no servidor?",
                answer: "Sim, todos os nossos planos de Palworld suportam mods e configurações personalizadas."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários do seu servidor, e você também pode criar backups manuais a qualquer momento."
            }
        ],
        testimonials: [
            {
                title: "Servidor estável",
                author: "Ricardo Almeida",
                content: "Servidor de Palworld muito estável, sem quedas e com ótimo desempenho mesmo com muitos jogadores online.",
                rating: 5
            },
            {
                title: "Suporte excelente",
                author: "Mariana Costa",
                content: "O suporte da NeonHost é excelente, me ajudaram a configurar mods no meu servidor de Palworld rapidamente.",
                rating: 5
            }
        ]
    },
    //   RUST
    {
        id: "rust",
        name: "Rust",
        slug: "rust",
        image: "/games/rust.webp",
        logo: "/games/rust.webp",
        featuredImage: "/games/rust.webp",
        description: "Sobrevivência hardcore em mundo hostil. Construa, lute e sobreviva em um dos jogos de sobrevivência mais desafiadores. Nossos servidores Rust oferecem performance excepcional e configurações personalizáveis.",
        shortDescription: "Sobrevivência hardcore em mundo hostil",
        price: 85.0,
        originalPrice: 120.0,
        discount: 29,
        category: "Sobrevivência",
        rating: 4.5,
        players: "9.2K",
        paymentLink: "https://app.neonhost.com.br/games/rust",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "Facepunch Studios",
        features: [
            "Configuração Personalizada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel RustAdmin",
            "Plugins Oxide",
            "Wipe Automático",
            "Mapas Customizados"
        ],
        minPlayers: 1,
        maxPlayers: 300,
        requirements: {
            ram: "6GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "15GB disponível"
        },
        plans: [
            {
                id: "rust-10gb",
                name: "Rust 10GB",
                price: 109.90,
                originalPrice: 120.0,
                players: 50,
                ram: "10GB",
                cpu: "4 vCores",
                storage: "45GB NVMe",
                features: [
                    "RustAdmin",
                    "Oxide",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Plugins Premium",
                    "Mapas Custom"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/rust/rust-10gb"
            },
            {
                id: "rust-16gb",
                name: "Rust 16GB",
                price: 169.9,
                originalPrice: 229.9,
                players: 100,
                ram: "16GB",
                cpu: "6 vCores",
                storage: "60GB NVMe",
                features: [
                    "RustAdmin",
                    "Oxide",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Plugins Premium",
                    "Mapas Custom"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/rust/rust-16gb"
            },
            {
                id: "rust-20gb",
                name: "Rust 20GB",
                price: 209.9,
                originalPrice: 290.9,
                players: 100,
                ram: "20GB",
                cpu: "6 vCores",
                storage: "75GB NVMe",
                features: [
                    "RustAdmin",
                    "Oxide",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Plugins Premium",
                    "Mapas Custom"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/rust/rust-20gb"
            }
        ],
        faq: [
            {
                question: "O que são plugins Oxide?",
                answer: "Oxide é um framework que permite adicionar plugins e modificações ao servidor Rust."
            },
            {
                question: "Como funciona o wipe automático?",
                answer: "Você pode configurar wipes automáticos semanais ou mensais através do painel de controle."
            }
        ],
        testimonials: [
            {
                title: "Performance excelente",
                author: "João Santos",
                content: "Servidor Rust com performance incrível, sem lag mesmo com 100 players online.",
                rating: 5
            }
        ]
    },
    //   CS2
    {
        id: "cs2",
        name: "Counter-Strike 2",
        slug: "counter-strike-2",
        image: "/games/cs2.webp",
        logo: "/games/cs2.webp",
        featuredImage: "/games/cs2.webp",
        description: "O FPS competitivo mais jogado do mundo. Crie seu servidor CS2 personalizado com mapas, modos de jogo e configurações exclusivas.",
        shortDescription: "O FPS competitivo mais jogado",
        price: 39.9,
        originalPrice: 59.9,
        discount: 33,
        category: "FPS",
        rating: 4.8,
        players: "12.5K",
        paymentLink: "https://app.neonhost.com.br/games/cs2",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "Valve Corporation",
        features: [
            "Mapas Customizados",
            "Plugins SourceMod",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Configuração Competitiva",
            "Workshop Integration"
        ],
        minPlayers: 2,
        maxPlayers: 64,
        requirements: {
            ram: "2GB mínimo",
            cpu: "Intel i3 ou AMD equivalente",
            storage: "8GB disponível"
        },
        plans: [
            {
                id: "cs2-2gb",
                name: "Counter-Strike 2 - 2GB",
                price: 29.9,
                originalPrice: 59.9,
                players: 20,
                ram: "2GB",
                cpu: "1 vCores",
                storage: "5GB NVMe",
                features: [
                    "SourceMod",
                    "Mapas Custom",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "128 Tick"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/counter-strike-2/counter-strike-2-2gb"
            },
            {
                id: "cs2-4gb",
                name: "Counter-Strike 2 - 4GB",
                price: 49.9,
                originalPrice: 78.9,
                players: 32,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "25GB NVMe",
                features: [
                    "SourceMod",
                    "Mapas Custom",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Plugins Premium",
                    "128 Tick"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/counter-strike-2/counter-strike-2-4gb"
            },
            {
                id: "cs2-6gb",
                name: "Counter-Strike 2 - 6GB",
                price: 69.9,
                originalPrice: 95.9,
                players: 64,
                ram: "6GB",
                cpu: "5 vCores",
                storage: "40GB NVMe",
                features: [
                    "SourceMod",
                    "Mapas Custom",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Plugins Premium",
                    "128 Tick"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/counter-strike-2/counter-strike-2-6gb"
            }
        ],
        faq: [
            {
                question: "Suporta 128 tick?",
                answer: "Sim, nossos servidores premium suportam 128 tick para melhor precisão competitiva."
            },
            {
                question: "Posso instalar plugins?",
                answer: "Sim, suportamos SourceMod e plugins personalizados."
            }
        ],
        testimonials: [
            {
                title: "Perfeito para competitivo",
                author: "Pedro Oliveira",
                content: "Uso para treinos da minha equipe, servidor sempre estável e com boa latência.",
                rating: 5
            }
        ]
    },
    //   ARK EVOLVED
    {
        id: "ark",
        name: "ARK: Survival Evolved",
        slug: "ark-survival-evolved",
        image: "/games/ark.avif",
        logo: "/games/ark.avif",
        featuredImage: "/games/ark.avif",
        description: "Sobreviva com dinossauros em um mundo pré-histórico. Domestique criaturas, construa bases e explore um mundo cheio de perigos e aventuras.",
        shortDescription: "Sobreviva com dinossauros",
        price: 89.9,
        originalPrice: 119.9,
        discount: 25,
        category: "Sobrevivência",
        rating: 4.4,
        players: "6.9K",
        paymentLink: "https://app.neonhost.com.br/games/ark",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "Xbox",
            "PlayStation"
        ],
        developer: "Studio Wildcard",
        features: [
            "Mods Steam Workshop",
            "Configuração Avançada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Crossplay",
            "Cluster Support"
        ],
        minPlayers: 1,
        maxPlayers: 100,
        requirements: {
            ram: "6GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "ark-6gb",
                name: "Ark Survival Evolved - 6GB",
                price: 80.27,
                originalPrice: 119.9,
                players: 20,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "40GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/ark-survival-evolved/ark-survival-evolved-6gb"
            },
            {
                id: "ark-16gb",
                name: "Ark Survival Evolved - 16GB",
                price: 129.27,
                originalPrice: 219.9,
                players: 50,
                ram: "16GB",
                cpu: "6 vCores",
                storage: "80GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Cluster",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/ark-survival-evolved/ark-survival-evolved-16gb"
            }
        ],
        faq: [
            {
                question: "Suporta mods do Steam Workshop?",
                answer: "Sim, você pode instalar qualquer mod disponível no Steam Workshop automaticamente."
            },
            {
                question: "O que é cluster?",
                answer: "Cluster permite conectar múltiplos mapas ARK para transferir personagens e itens entre eles."
            }
        ],
        testimonials: [
            {
                title: "Servidor estável",
                author: "Lucas Ferreira",
                content: "Jogo ARK há anos, esse é o servidor mais estável que já usei. Recomendo!",
                rating: 5
            }
        ]
    },
    //   Ark Survival Ascended
    {
        id: "ark-ascended",
        name: "Ark Survival Ascended",
        slug: "ark-survival-ascended",
        image: "/games/arkAscended.jpg",
        logo: "/games/arkAscended.jpg",
        featuredImage: "/games/arkAscended.jpg",
        description: "Sobreviva com dinossauros em um mundo pré-histórico. Domestique criaturas, construa bases e explore um mundo cheio de perigos e aventuras.",
        shortDescription: "Sobreviva com dinossauros",
        price: 89.9,
        originalPrice: 119.9,
        discount: 25,
        category: "Sobrevivência",
        rating: 4.4,
        players: "6.9K",
        paymentLink: "https://app.neonhost.com.br/games/ark-ascended",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "Xbox",
            "PlayStation"
        ],
        developer: "Studio Wildcard",
        features: [
            "Mods Steam Workshop",
            "Configuração Avançada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Crossplay",
            "Cluster Support"
        ],
        minPlayers: 1,
        maxPlayers: 100,
        requirements: {
            ram: "6GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "ark-6gb",
                name: "Ark Survival Evolved - 6GB",
                price: 80.27,
                originalPrice: 119.9,
                players: 20,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "40GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/ark-survival-evolved/ark-survival-evolved-6gb"
            },
            {
                id: "ark-16gb",
                name: "Ark Survival Evolved - 16GB",
                price: 129.27,
                originalPrice: 219.9,
                players: 50,
                ram: "16GB",
                cpu: "6 vCores",
                storage: "80GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Cluster",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/ark-survival-evolved/ark-survival-evolved-16gb"
            }
        ],
        faq: [
            {
                question: "Suporta mods do Steam Workshop?",
                answer: "Sim, você pode instalar qualquer mod disponível no Steam Workshop automaticamente."
            },
            {
                question: "O que é cluster?",
                answer: "Cluster permite conectar múltiplos mapas ARK para transferir personagens e itens entre eles."
            }
        ],
        testimonials: [
            {
                title: "Servidor estável",
                author: "Lucas Ferreira",
                content: "Jogo ARK há anos, esse é o servidor mais estável que já usei. Recomendo!",
                rating: 5
            }
        ]
    },
    //   Euro Truck Simulator 2
    {
        id: "euro-truck-simulator-2",
        name: "Euro Truck Simulator 2",
        slug: "euro-truck-simulator-2",
        image: "/games/Euro_Truck_Simulator_2.png",
        logo: "/games/Euro_Truck_Simulator_2.png",
        featuredImage: "/games/Euro_Truck_Simulator_2.png",
        description: "Sobreviva com dinossauros em um mundo pré-histórico. Domestique criaturas, construa bases e explore um mundo cheio de perigos e aventuras.",
        shortDescription: "Sobreviva com dinossauros",
        price: 34.98,
        category: "Simulação",
        rating: 4.4,
        players: "6.9K",
        paymentLink: "https://app.neonhost.com.br/games/euro-truck-simulator-2",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "SCS Software",
        isNew: true,
        isPopular: true,
        features: [
            "Mods Steam Workshop",
            "Configuração Avançada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Crossplay",
            "Cluster Support"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "6GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "euro-truck-1gb",
                name: "Euro Truck Simulator - 1GB",
                price: 34.98,
                players: 20,
                ram: "1GB",
                cpu: "4 vCores",
                storage: "5GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/euro-truck-simulator-2/euro-truck-simulator-1gb"
            },
            {
                id: "euro-truck-2gb",
                name: "Euro Truck Simulator - 2GB",
                price: 67.78,
                players: 50,
                ram: "2GB",
                cpu: "4 vCores",
                storage: "5GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/euro-truck-simulator-2/euro-truck-simulator-2gb"
            },
            {
                id: "euro-truck-3gb",
                name: "Euro Truck Simulator - 3GB",
                price: 67.78,
                players: 50,
                ram: "3GB",
                cpu: "4 vCores",
                storage: "5GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/euro-truck-simulator-2/euro-truck-simulator-3gb"
            }
        ],
        faq: [
            {
                question: "Suporta mods do Steam Workshop?",
                answer: "Sim, você pode instalar qualquer mod disponível no Steam Workshop automaticamente."
            },
            {
                question: "O que é cluster?",
                answer: "Cluster permite conectar múltiplos mapas ARK para transferir personagens e itens entre eles."
            }
        ],
        testimonials: []
    },
    //   Node.js
    {
        id: "node-js",
        name: "Node Js",
        slug: "node-js",
        image: "/games/neon_nodejs.png",
        logo: "/games/neon_nodejs.png",
        featuredImage: "/games/neon_nodejs.png",
        description: "",
        shortDescription: "Desenvolva e hospede aplicações Node.js com facilidade",
        price: 4.99,
        category: "Ferramentas",
        rating: 4.7,
        players: "600.9K",
        paymentLink: "https://app.neonhost.com.br/games/node-js",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "NodeJS",
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 0,
        maxPlayers: 0,
        requirements: {
            ram: "512MB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "nodejs-starter",
                name: "NodeJS - 1GB",
                price: 4.99,
                players: 0,
                ram: "1GB",
                cpu: "2 vCores",
                storage: "10GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-iniciante"
            },
            {
                id: "nodejs-professional",
                name: "NodeJS - 2GB",
                price: 9.99,
                players: 0,
                ram: "2GB",
                cpu: "2 vCores",
                storage: "25GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-professional"
            },
            {
                id: "nodejs-business",
                name: "NodeJS - 4GB",
                price: 19.99,
                players: 0,
                ram: "4GB",
                cpu: "4 vCores",
                storage: "55GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-business"
            },
            {
                id: "nodejs-enterprise",
                name: "NodeJS - 8GB",
                price: 39.99,
                players: 0,
                ram: "8GB",
                cpu: "6 vCores",
                storage: "100GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-enterprise"
            },
            {
                id: "nodejs-scale",
                name: "NodeJS - 8GB",
                price: 79.99,
                players: 0,
                ram: "16GB",
                cpu: "8 vCores",
                storage: "200GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-scale"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: [
            {
                title: "Servidor estável",
                author: "Lucas Ferreira",
                content: "Utilizo o NodeJs há anos, esse é o servidor mais estável que já usei. Recomendo!",
                rating: 5
            }
        ]
    },
    //   Python Py
    {
        id: "python-py",
        name: "Python Py",
        slug: "python-py",
        image: "/games/neon_pythonpy.png",
        logo: "/games/neon_pythonpy.png",
        featuredImage: "/games/neon_pythonpy.png",
        description: "",
        shortDescription: "Desenvolva e hospede aplicações Node.js com facilidade",
        price: 4.99,
        category: "Ferramentas",
        rating: 4.7,
        players: "600.9K",
        paymentLink: "https://app.neonhost.com.br/games/python-py",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "NodeJS",
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 0,
        maxPlayers: 0,
        requirements: {
            ram: "512MB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "nodejs-starter",
                name: "NodeJS - 1GB",
                price: 4.99,
                players: 0,
                ram: "1GB",
                cpu: "2 vCores",
                storage: "10GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-iniciante"
            },
            {
                id: "nodejs-professional",
                name: "NodeJS - 2GB",
                price: 9.99,
                players: 0,
                ram: "2GB",
                cpu: "2 vCores",
                storage: "25GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-professional"
            },
            {
                id: "nodejs-business",
                name: "NodeJS - 4GB",
                price: 19.99,
                players: 0,
                ram: "4GB",
                cpu: "4 vCores",
                storage: "55GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-business"
            },
            {
                id: "nodejs-enterprise",
                name: "NodeJS - 8GB",
                price: 39.99,
                players: 0,
                ram: "8GB",
                cpu: "6 vCores",
                storage: "100GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-enterprise"
            },
            {
                id: "nodejs-scale",
                name: "NodeJS - 8GB",
                price: 79.99,
                players: 0,
                ram: "16GB",
                cpu: "8 vCores",
                storage: "200GB NVMe",
                features: [
                    "Node.js 18+LTS",
                    "MySQL 8.0",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "FTS/SFTP Access"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/nodejs/service-nodejs-scale"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: [
            {
                title: "Servidor estável",
                author: "Lucas Ferreira",
                content: "Utilizo o NodeJs há anos, esse é o servidor mais estável que já usei. Recomendo!",
                rating: 5
            }
        ]
    },
    //   Terraria
    {
        id: "terraria",
        name: "Terraria",
        slug: "terraria",
        image: "/games/terraria.jpg",
        logo: "/games/terraria.jpg",
        featuredImage: "/games/terraria.jpg",
        description: "",
        shortDescription: "Terraria é um jogo de aventura e construção em 2D, onde você pode explorar, construir e lutar contra criaturas em um mundo gerado aleatoriamente.",
        price: 9.44,
        category: "Eletrônico de plataforma",
        rating: 4.9,
        players: "60.9K",
        paymentLink: "https://app.neonhost.com.br/games/terraria",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "Pipeworks Studio",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 0,
        maxPlayers: 0,
        requirements: {
            ram: "2GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "terraria-starter",
                name: "Terraria - 2GB",
                price: 9.44,
                players: 0,
                ram: "2GB",
                cpu: "2 vCores",
                storage: "5GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-terraria/terraria-1gb"
            },
            {
                id: "terraria-professional",
                name: "Terraria - 4GB",
                price: 35.92,
                players: 0,
                ram: "4GB",
                cpu: "2 vCores",
                storage: "5.9GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-terraria/terraria-4gb"
            },
            {
                id: "terraria-business",
                name: "Terraria - 6GB",
                price: 83.27,
                players: 0,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "5.9GB NVMe",
                features: [
                    "Mods Workshop",
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-terraria/terraria-6gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   Red Dead Redemption 2
    {
        id: "redm",
        name: "Red Dead Redemption 2",
        slug: "redm",
        image: "/games/redM.png",
        logo: "/games/redM.png",
        featuredImage: "/games/redTemion.jpg",
        description: "",
        shortDescription: "Red Dead Redemption 2 é um jogo de ação e aventura em mundo aberto, ambientado no Velho Oeste americano.",
        price: 96.90,
        category: "Eletrônico de plataforma",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/redm",
        vpsLink: "/redm",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "PlayStation",
            "Xbox"
        ],
        developer: "Rockstar Games",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 75,
        maxPlayers: 2048,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "redm-starter",
                name: "Red Dead Redemption 2 - 4GB",
                price: 96.90,
                players: 75,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "50GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-redm/red-dead-redemption-2-4gb"
            },
            {
                id: "redm-professional",
                name: "Red Dead Redemption 2 - 6GB",
                price: 149.90,
                players: 250,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "60GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-redm/red-dead-redemption-2-6gb"
            },
            {
                id: "redm-business",
                name: "Red Dead Redemption 2 - 8GB",
                price: 189.90,
                players: 500,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "70GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-redm/red-dead-redemption-2-8gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   FiveM
    {
        id: "fivem",
        name: "FiveM",
        slug: "fivem",
        image: "/games/fivem.webp",
        logo: "/games/fivem.webp",
        featuredImage: "/games/fivembg.jpg",
        description: "",
        shortDescription: "FiveM é uma modificação para Grand Theft Auto V que permite aos jogadores criar e jogar em servidores personalizados.",
        price: 96.90,
        category: "Eletrônico de plataforma",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/fivem",
        vpsLink: "/fivem",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "PlayStation",
            "Xbox"
        ],
        developer: "Rockstar Games",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 75,
        maxPlayers: 2048,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "fivem-starter",
                name: "FiveM - 4GB",
                price: 96.90,
                players: 75,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "50GB NVMe",
                features: [
                    "Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-1"
            },
            {
                id: "fivem-professional",
                name: "FiveM - 6GB",
                price: 129.90,
                players: 250,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "60GB NVMe",
                features: [
                    "Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-2"
            },
            {
                id: "fivem-business",
                name: "FiveM - 8GB",
                price: 189.90,
                players: 500,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "70GB NVMe",
                features: [
                    "Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/vps-fivem/vps-fivem-3"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   Valheim
    {
        id: "valheim",
        name: "Valheim",
        slug: "valheim",
        image: "/games/valheim_nh25.jpg",
        logo: "/games/valheim_nh25.jpg",
        featuredImage: "/games/valheim_nh25.jpg",
        description: "",
        shortDescription: "Valheim é um jogo de sobrevivência e exploração em um mundo aberto inspirado na mitologia nórdica.",
        price: 49.90,
        category: "Eletrônico de plataforma",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/valheim",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "Iron Gate AB",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "valheim-starter",
                name: "Valheim - 4GB",
                price: 49.90,
                players: 5,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/valheim/valheim-4gb"
            },
            {
                id: "valheim-professional",
                name: "Valheim - 6GB",
                price: 69.90,
                players: 10,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "15GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/valheim/valheim-6gb"
            },
            {
                id: "valheim-business",
                name: "Valheim - 8GB",
                price: 89.90,
                players: 32,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "70GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-ptero-fivem/fivem-8gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   Valheim
    {
        id: "astroneer",
        name: "Astroneer",
        slug: "astroneer",
        image: "/games/astroneer.avif",
        logo: "/games/astroneer.avif",
        featuredImage: "/games/astroneer.avif",
        description: "",
        shortDescription: "Valheim é um jogo de sobrevivência e exploração em um mundo aberto inspirado na mitologia nórdica.",
        price: 49.90,
        category: "Eletrônico de plataforma",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/astroneer",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "Nintendo Switch",
            "PC",
            "PlayStation",
            "Xbox"
        ],
        developer: "System Era Softworks",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "astroneer-starter",
                name: "Astroneer - 4GB",
                price: 49.90,
                players: 8,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/astroneer/astroneer-4gb"
            },
            {
                id: "astroneer-professional",
                name: "Astroneer - 6GB",
                price: 71.85,
                players: 42,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/astroneer/astroneer-6gb"
            },
            {
                id: "astroneer-business",
                name: "Astroneer - 8GB",
                price: 178.48,
                players: 100,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/astroneer/astroneer-8gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   Conan Exiles
    {
        id: "conan-exiles",
        name: "Conan Exiles",
        slug: "conan-exiles",
        image: "/games/conanexiles.jpg",
        logo: "/games/conanexiles.jpg",
        featuredImage: "/games/conanexiles.jpg",
        description: "",
        shortDescription: "Conan Exiles é um jogo de sobrevivência e construção em mundo aberto, ambientado no universo de Conan, o Bárbaro.",
        price: 94.56,
        category: "Sbrevivência",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/astroneer",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "PlayStation",
            "Xbox"
        ],
        developer: "Funcom",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "conan-exiles-starter",
                name: "Conan Exiles - 4GB",
                price: 94.56,
                players: 16,
                ram: "4GB",
                cpu: "3 vCores",
                storage: "15GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-conan-exiles/conan-exiles-4gb"
            },
            {
                id: "conan-exiles-professional",
                name: "Conan Exiles - 6GB",
                price: 135.85,
                players: 32,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-conan-exiles/conan-exiles-6gb"
            },
            {
                id: "conan-exiles-business",
                name: "Conan Exiles - 8GB",
                price: 245.48,
                players: 200,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/hospedagem-conan-exiles/conan-exiles-8gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //   Multi Theft Auto: San Andreas (MTA)
    {
        id: "multi-theft-auto-san-andreas-mta",
        name: "Multi Theft Auto: San Andreas (MTA)",
        slug: "multi-theft-auto-san-andreas-mta",
        image: "/games/mta.jpg",
        logo: "/games/mta.jpg",
        featuredImage: "/games/mta_banner.jpg",
        description: "",
        shortDescription: "Multi Theft Auto: San Andreas é uma modificação para o jogo Grand Theft Auto: San Andreas que permite jogar online em servidores personalizados.",
        price: 27.99,
        category: "Sbrevivência",
        rating: 4.9,
        players: "120.9K",
        paymentLink: "https://app.neonhost.com.br/games/astroneer",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC",
            "PlayStation",
            "Xbox"
        ],
        developer: "Rockstar Games",
        isNew: true,
        isPopular: true,
        features: [
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle"
        ],
        minPlayers: 1,
        maxPlayers: 32,
        requirements: {
            ram: "4GB mínimo",
            cpu: "Intel i7 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "multi-theft-auto-san-andreas-mta-starter",
                name: "Multi Theft Auto - 1GB",
                price: 27.99,
                players: 999,
                ram: "1GB",
                cpu: "1 vCores",
                storage: "5GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/mtasa/multi-theft-auto-san-andreas-1gb"
            },
            {
                id: "multi-theft-auto-san-andreas-mta-professional",
                name: "Multi Theft Auto - 5GB",
                price: 39.90,
                players: 999,
                ram: "5GB",
                cpu: "3 vCores",
                storage: "10GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/mtasa/multi-theft-auto-san-andreas-5gb"
            },
            {
                id: "multi-theft-auto-san-andreas-mta-business",
                name: "Multi Theft Auto - 8GB",
                price: 59.90,
                players: 999,
                ram: "8GB",
                cpu: "5 vCores",
                storage: "20GB NVMe",
                features: [
                    "Sem Acesso SSh",
                    "Painel Web",
                    "AMD Ryzen 9",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/mtasa/multi-theft-auto-san-andreas-8gb"
            }
        ],
        faq: [
            {
                question: "Qual a velocidade do link?",
                answer: "Todos os nossos serviços contam com link de 1Gbps. Além disso, utilizamos as melhores rotas e infraestrutura de rede para garantir baixa latência e alta disponibilidade."
            },
            {
                question: "Como funciona o backup?",
                answer: "Realizamos backups automáticos diários de todos os serviços e mantemos as últimas 7 versões. Você também pode criar backups manuais a qualquer momento através do painel de controle."
            }
        ],
        testimonials: []
    },
    //  Icarus
    {
        id: "icarus",
        name: "Icarus",
        slug: "icarus",
        image: "/games/icarus.webp",
        logo: "/games/icarus.webp",
        featuredImage: "/games/icarus.webp",
        description: "ICARUS é um jogo de sobrevivência PvE com modos de mundo aberto persistentes e baseados em missões para até oito jogadores cooperativos.",
        shortDescription: "Sobreviva",
        price: 89.90,
        category: "Simulação",
        rating: 4.8,
        players: "6.9K",
        paymentLink: "https://app.neonhost.com.br/games/icarus",
        vpsLink: "/vps-gamer",
        communityLink: "https://discord.gg/neonhost",
        platforms: [
            "PC"
        ],
        developer: "RocketWerkz",
        isNew: true,
        isPopular: false,
        features: [
            "Mods Steam Workshop",
            "Configuração Avançada",
            "Backup Automático",
            "Suporte 24/7",
            "Anti-DDoS Incluído",
            "Painel de Controle",
            "Crossplay",
            "Cluster Support"
        ],
        minPlayers: 1,
        maxPlayers: 12,
        requirements: {
            ram: "6GB mínimo",
            cpu: "Intel i5 ou AMD equivalente",
            storage: "20GB disponível"
        },
        plans: [
            {
                id: "icarus-6gb",
                name: "Icarus - 6GB",
                price: 89.90,
                players: 3,
                ram: "6GB",
                cpu: "4 vCores",
                storage: "15GB NVMe",
                features: [
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/icarus/icarus-6gb"
            },
            {
                id: "icarus-10gb",
                name: "Icarus - 10GB",
                price: 109.78,
                players: 6,
                ram: "10GB",
                cpu: "4 vCores",
                storage: "20GB NVMe",
                features: [
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/icarus/icarus-10gb"
            },
            {
                id: "Icarus-16gb",
                name: "Icarus - 16GB",
                price: 139.90,
                players: 8,
                ram: "16GB",
                cpu: "4 vCores",
                storage: "25GB NVMe",
                features: [
                    "Painel Web",
                    "Backup Automático",
                    "Suporte 24/7",
                    "Anti-DDoS",
                    "Configuração Avançada"
                ],
                paymentLink: "https://app.neonhost.com.br/index.php?rp=/store/icarus/icarus-16gb"
            }
        ],
        faq: [
            {
                question: "Suporta mods do Steam Workshop?",
                answer: "Sim, você pode instalar qualquer mod disponível no Steam Workshop automaticamente."
            },
            {
                question: "O que é cluster?",
                answer: "Cluster permite conectar múltiplos mapas ARK para transferir personagens e itens entre eles."
            }
        ],
        testimonials: []
    }
];
function getGameById(id) {
    return gamesConfig.find((game)=>game.id === id || game.slug === id);
}
function getGamesByCategory(category) {
    return gamesConfig.filter((game)=>game.category.toLowerCase() === category.toLowerCase());
}
function getFeaturedGames() {
    return gamesConfig.filter((game)=>game.isFeatured);
}
function getPopularGames() {
    return gamesConfig.filter((game)=>game.isPopular);
}
function getNewGames() {
    return gamesConfig.filter((game)=>game.isNew);
}
function getDiscountedGames() {
    return gamesConfig.filter((game)=>game.discount && game.discount > 0);
}
function searchGames(query) {
    const lowercaseQuery = query.toLowerCase();
    return gamesConfig.filter((game)=>game.name.toLowerCase().includes(lowercaseQuery) || game.category.toLowerCase().includes(lowercaseQuery) || game.description.toLowerCase().includes(lowercaseQuery));
}
function getGameCategories() {
    const categories = gamesConfig.map((game)=>game.category);
    const uniqueCategories = Array.from(new Set(categories));
    return uniqueCategories;
}

})()),
"[project]/app/games/page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>GamesPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$maintenance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/config/maintenance.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$maintenance$2d$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/maintenance-page.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/config/games.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/heart.js [app-ssr] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/shopping-cart.js [app-ssr] (ecmascript) <export default as ShoppingCart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-ssr] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-ssr] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-ssr] (ecmascript) <export default as Sparkles>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/trending-up.js [app-ssr] (ecmascript) <export default as TrendingUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-ssr] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/gift.js [app-ssr] (ecmascript) <export default as Gift>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/play.js [app-ssr] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/external-link.js [app-ssr] (ecmascript) <export default as ExternalLink>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
;
;
;
const gameCategories = {
    bestsellers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPopularGames"])().slice(0, 3),
    vpsGames: [
        {
            id: "dayz",
            name: "DayZ",
            price: 74.9,
            image: "/games/dayzF.webp"
        },
        {
            id: "ragnarok",
            name: "Ragnarok",
            price: 74.9,
            image: "/games/ragnarok.jpg"
        },
        {
            id: "redm",
            name: "RedM",
            price: 74.9,
            image: "/games/redM.png"
        }
    ],
    upcoming: [
        {
            id: "gta6",
            name: "GTA 6",
            status: "Em breve",
            image: "/games/gta6.jpg"
        }
    ]
};
const newsGuides = [
    {
        id: 1,
        title: "Atualize seu jogo",
        description: "Seu servidor de jogo atualizou e você não sabe como atualizar, não se preocupe acompanhe nosso guia e atualize seu servidor em segundos!",
        image: "/games/palworld.webp",
        category: "Guia",
        link: "/blog/atualizar-servidor"
    },
    {
        id: 2,
        title: "Instale Modpacks automático",
        description: "Você não tem conhecimento em Minecraft? Isso não é um problema com nossos sistemas você pode instalar Modpacks de forma automática com apenas 1 click!",
        image: "/games/minecraft.webp",
        category: "Tutorial",
        link: "/blog/modpacks-automatico"
    },
    {
        id: 3,
        title: "Abra uma cidade Roleplay",
        description: "Para de perder tempo, e abra seu servidor de FiveM com a NeonHost, processadores AMD Ryzen e Proteção Anti DDoS, você possui estabilidade e segurança!",
        image: "/games/cf22a625de9672e1250f31aee91daf3a.jpg",
        category: "Dica",
        link: "/blog/servidor-fivem"
    }
];
function GamesPage() {
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("descobrir");
    const [wishlist, setWishlist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cart, setCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [filteredGames, setFilteredGames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["gamesConfig"]);
    const [currentGameIndex, setCurrentGameIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const featuredGame = (0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFeaturedGames"])()[0] || __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["gamesConfig"][0];
    const gamesInHighlight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPopularGames"])().slice(0, 5);
    // Filtrar jogos baseado na busca
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (searchTerm) {
            setFilteredGames((0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["searchGames"])(searchTerm));
        } else {
            switch(activeTab){
                case "novidades":
                    setFilteredGames((0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getNewGames"])());
                    break;
                case "navegar":
                    setFilteredGames((0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDiscountedGames"])());
                    break;
                default:
                    setFilteredGames(__TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["gamesConfig"]);
            }
        }
    }, [
        searchTerm,
        activeTab
    ]);
    const handleSearch = (e)=>{
        setSearchTerm(e.target.value);
    };
    const toggleWishlist = (gameId)=>{
        setWishlist((prev)=>prev.includes(gameId) ? prev.filter((id)=>id !== gameId) : [
                ...prev,
                gameId
            ]);
    };
    const addToCart = (gameId)=>{
        if (!cart.includes(gameId)) {
            setCart((prev)=>[
                    ...prev,
                    gameId
                ]);
        }
    };
    const nextGames = ()=>{
        setCurrentGameIndex((prev)=>prev + 6 >= filteredGames.length ? 0 : prev + 6);
    };
    const prevGames = ()=>{
        setCurrentGameIndex((prev)=>prev - 6 < 0 ? Math.max(0, filteredGames.length - 6) : prev - 6);
    };
    const handleTabChange = (tab)=>{
        setActiveTab(tab);
        setIsLoading(true);
        // Simular carregamento
        setTimeout(()=>{
            setIsLoading(false);
        }, 500);
    };
    const handleBuyNow = (gameId)=>{
        const game = __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["gamesConfig"].find((g)=>g.id === gameId);
        if (game) {
            window.open(game.paymentLink, "_blank");
        }
    };
    if (__TURBOPACK__imported__module__$5b$project$5d2f$config$2f$maintenance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["maintenanceConfig"].isGamesUnderMaintenance) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$maintenance$2d$page$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MaintenancePage"], {
            title: __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$maintenance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["maintenanceConfig"].title,
            subtitle: __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$maintenance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["maintenanceConfig"].subtitle,
            description: __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$maintenance$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["maintenanceConfig"].description,
            showBackButton: true,
            backUrl: "/"
        }, void 0, false, {
            fileName: "[project]/app/games/page.tsx",
            lineNumber: 146,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-0 left-0 w-[600px] h-[600px] bg-gradient-to-br from-purple-500/15 via-purple-500/8 to-transparent rounded-full blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/app/games/page.tsx",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute bottom-0 right-0 w-[600px] h-[600px] bg-gradient-to-tl from-pink-500/15 via-pink-500/8 to-transparent rounded-full blur-3xl"
                    }, void 0, false, {
                        fileName: "[project]/app/games/page.tsx",
                        lineNumber: 161,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/games/page.tsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 pt-24 pb-8 relative z-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-4xl font-bold mb-2 relative text-gray-900 dark:text-white",
                                        children: [
                                            "Explore Nossos",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent",
                                                children: "Jogos"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 170,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 168,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-32 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 172,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 167,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative w-80",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                        className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 z-10"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 175,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "text",
                                        placeholder: "Pesquisar jogos...",
                                        value: searchTerm,
                                        onChange: handleSearch,
                                        className: "w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-500/20 backdrop-blur-sm transition-all duration-300"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 176,
                                        columnNumber: 13
                                    }, this),
                                    searchTerm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute top-full left-0 right-0 mt-2 bg-white/95 dark:bg-gray-800/95 backdrop-blur-sm border border-gray-200 dark:border-gray-700 rounded-lg shadow-2xl z-20",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-sm text-gray-600 dark:text-gray-400 mb-2",
                                                    children: [
                                                        "Resultados (",
                                                        filteredGames.length,
                                                        ")"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 19
                                                }, this),
                                                filteredGames.slice(0, 5).map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/games/${game.id}`,
                                                        className: "flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "w-8 h-8 rounded overflow-hidden",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: game.image || "/placeholder.svg",
                                                                    alt: game.name,
                                                                    width: 32,
                                                                    height: 32,
                                                                    className: "object-cover"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 194,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 193,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "font-semibold text-sm text-gray-900 dark:text-white",
                                                                        children: game.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 203,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-xs text-purple-600 dark:text-purple-400",
                                                                        children: [
                                                                            "R$ ",
                                                                            game.price.toFixed(2).replace(".", ",")
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 204,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 202,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, game.id, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 188,
                                                        columnNumber: 21
                                                    }, this))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 185,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 184,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/games/page.tsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-8 mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTabChange("descobrir"),
                                className: `flex items-center gap-2 pb-2 transition-all duration-300 ${activeTab === "descobrir" ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-400 dark:border-purple-500" : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 224,
                                        columnNumber: 13
                                    }, this),
                                    "Descobrir"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 216,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTabChange("navegar"),
                                className: `flex items-center gap-2 pb-2 transition-all duration-300 ${activeTab === "navegar" ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-400 dark:border-purple-500" : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trending$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TrendingUp$3e$__["TrendingUp"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 235,
                                        columnNumber: 13
                                    }, this),
                                    "Navegar"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 227,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleTabChange("novidades"),
                                className: `flex items-center gap-2 pb-2 transition-all duration-300 ${activeTab === "novidades" ? "text-purple-600 dark:text-purple-400 border-b-2 border-purple-400 dark:border-purple-500" : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 246,
                                        columnNumber: 13
                                    }, this),
                                    "Novidades"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 238,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/games/page.tsx",
                        lineNumber: 215,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/games/page.tsx",
                lineNumber: 165,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container mx-auto px-4 relative z-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 lg:grid-cols-4 gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative rounded-2xl overflow-hidden mb-12 bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900 group border border-gray-200 dark:border-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute inset-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: featuredGame.image || "/placeholder.svg",
                                                    alt: featuredGame.name,
                                                    fill: true,
                                                    className: "object-cover opacity-20 group-hover:opacity-30 transition-opacity duration-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 259,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 bg-gradient-to-r from-white/90 dark:from-gray-900/90 via-white/60 dark:via-gray-900/60 to-transparent"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 265,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 258,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative p-8 lg:p-12",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "max-w-2xl",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "inline-block bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-bold px-3 py-1 rounded-full mb-4",
                                                        children: "JÁ DISPONÍVEL"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 270,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-5xl font-bold mb-4 text-gray-900 dark:text-white",
                                                        children: featuredGame.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 274,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-gray-700 dark:text-gray-300 text-lg mb-6 leading-relaxed",
                                                        children: featuredGame.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4 mb-8",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2",
                                                                children: [
                                                                    featuredGame.originalPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-gray-500 dark:text-gray-400 line-through text-lg",
                                                                        children: [
                                                                            "R$ ",
                                                                            featuredGame.originalPrice.toFixed(2).replace(".", ",")
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 280,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-3xl font-bold text-gray-900 dark:text-white",
                                                                        children: [
                                                                            "R$ ",
                                                                            featuredGame.price.toFixed(2).replace(".", ",")
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 284,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 278,
                                                                columnNumber: 21
                                                            }, this),
                                                            featuredGame.discount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-bold px-3 py-1 rounded-full",
                                                                children: [
                                                                    "-",
                                                                    featuredGame.discount,
                                                                    "%"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 289,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 277,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handleBuyNow(featuredGame.id),
                                                                className: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105 shadow-lg flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                                                                        className: "w-5 h-5"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 300,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    "Comprar agora"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 296,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>toggleWishlist(featuredGame.id),
                                                                className: `p-3 rounded-xl border transition-all duration-300 ${wishlist.includes(featuredGame.id) ? "bg-purple-600 border-purple-600 text-white" : "border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:border-purple-500 hover:text-purple-600 dark:hover:text-purple-400"}`,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                                                    className: "w-5 h-5"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 311,
                                                                    columnNumber: 23
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 303,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 295,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 269,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 268,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 257,
                                    columnNumber: 13
                                }, this),
                                isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-center py-20",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "animate-spin rounded-full h-12 w-12 border-2 border-purple-500 border-t-transparent"
                                    }, void 0, false, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 321,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 320,
                                    columnNumber: 15
                                }, this),
                                !isLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "mb-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between mb-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-2xl font-bold text-gray-900 dark:text-white",
                                                    children: [
                                                        activeTab === "descobrir" && "Todos os serviços",
                                                        activeTab === "navegar" && "Jogos com desconto",
                                                        activeTab === "novidades" && "Novos lançamentos"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 329,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: prevGames,
                                                            className: "p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                                                className: "w-5 h-5 text-gray-600 dark:text-gray-400"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 339,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 335,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: nextGames,
                                                            className: "p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                                className: "w-5 h-5 text-gray-600 dark:text-gray-400"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 345,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 341,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 334,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 328,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4",
                                            children: filteredGames.slice(currentGameIndex, currentGameIndex + 6).map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "group relative",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all duration-300 group-hover:scale-105 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "aspect-[4/3] relative",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: game.image || "/placeholder.svg",
                                                                        alt: game.name,
                                                                        fill: true,
                                                                        className: "object-cover"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 355,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    game.discount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute top-2 left-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-bold px-2 py-1 rounded-full",
                                                                        children: [
                                                                            "-",
                                                                            game.discount,
                                                                            "%"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 357,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute top-2 right-2",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>toggleWishlist(game.id),
                                                                            className: `p-1.5 rounded-full backdrop-blur-sm transition-all duration-300 ${wishlist.includes(game.id) ? "bg-purple-600 text-white" : "bg-white/80 dark:bg-gray-900/80 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"}`,
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                                                                className: "w-3 h-3"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 370,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 362,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 361,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                href: `/games/${game.id}`,
                                                                                className: "bg-white/20 backdrop-blur-sm p-2 rounded-full hover:bg-white/30 transition-colors",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                                                    className: "w-4 h-4 text-white"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 380,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 376,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>addToCart(game.id),
                                                                                className: "bg-purple-600 p-2 rounded-full hover:bg-purple-700 transition-colors",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shopping$2d$cart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShoppingCart$3e$__["ShoppingCart"], {
                                                                                    className: "w-4 h-4 text-white"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 386,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 382,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 375,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 354,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "font-semibold text-sm mb-1 truncate group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                        children: game.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 391,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-1 mb-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                                                                                className: "w-3 h-3 text-yellow-500 fill-current"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 395,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-xs text-gray-600 dark:text-gray-400",
                                                                                children: game.rating
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 396,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-xs text-gray-400",
                                                                                children: "•"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 397,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-xs text-gray-600 dark:text-gray-400",
                                                                                children: game.players
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 398,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 394,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-2",
                                                                        children: [
                                                                            game.originalPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-gray-400 dark:text-gray-500 line-through text-xs",
                                                                                children: [
                                                                                    "R$ ",
                                                                                    game.originalPrice.toFixed(2).replace(".", ",")
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 402,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-gray-900 dark:text-white font-bold text-sm",
                                                                                children: [
                                                                                    "R$ ",
                                                                                    game.price.toFixed(2).replace(".", ",")
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 406,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 400,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 390,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 353,
                                                        columnNumber: 23
                                                    }, this)
                                                }, game.id, false, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 352,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 350,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 327,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "mb-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between mb-6",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-2xl font-bold text-gray-900 dark:text-white",
                                                children: "Notícias & Guias"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 421,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 420,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-1 md:grid-cols-3 gap-6",
                                            children: newsGuides.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl overflow-hidden hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all duration-300 group-hover:scale-105 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "aspect-[16/10] relative",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: item.image || "/placeholder.svg",
                                                                    alt: item.title,
                                                                    fill: true,
                                                                    className: "object-cover"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 431,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 432,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 430,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "p-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-purple-600 dark:text-purple-400 text-sm font-semibold mb-2",
                                                                    children: item.category
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 435,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "font-bold mb-2 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                    children: item.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 436,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-600 dark:text-gray-400 text-sm leading-relaxed mb-4",
                                                                    children: item.description
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 439,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 434,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, item.id, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 426,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 424,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 419,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "mb-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl font-bold mb-6 text-gray-900 dark:text-white",
                                            children: "Categorias de Jogos"
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 448,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-1 md:grid-cols-3 gap-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600 transition-colors group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between mb-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "text-lg font-bold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                    children: "Mais Vendidos"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 454,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                    className: "w-5 h-5 text-purple-600 dark:text-purple-400"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 457,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 453,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-3",
                                                            children: gameCategories.bestsellers.map((game, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/games/${game.id}`,
                                                                    className: "flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors group",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-12 h-12 rounded-lg overflow-hidden flex-shrink-0",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                src: game.image || "/placeholder.svg",
                                                                                alt: game.name,
                                                                                width: 48,
                                                                                height: 48,
                                                                                className: "object-cover w-full h-full"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 467,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 466,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                                    children: game.name
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 476,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-purple-600 dark:text-purple-400 font-bold",
                                                                                    children: [
                                                                                        "R$ ",
                                                                                        game.price.toFixed(2).replace(".", ",")
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 479,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 475,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                            className: "w-4 h-4 text-gray-400 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 481,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, game.id, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 461,
                                                                    columnNumber: 23
                                                                }, this))
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 459,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            href: "/games/category/bestsellers",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "w-full mt-4 border border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/50 bg-transparent py-2 px-4 rounded-lg font-semibold transition-all duration-300",
                                                                children: "Ver todos"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 486,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 485,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 452,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600 transition-colors group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between mb-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "text-lg font-bold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                    children: "Jogos VPS"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 495,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                    className: "w-5 h-5 text-purple-600 dark:text-purple-400"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 498,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 494,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-3",
                                                            children: gameCategories.vpsGames.map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    href: `/games/${game.id}`,
                                                                    className: "flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors group",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200 dark:bg-gray-700",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                src: game.image || "/placeholder.svg",
                                                                                alt: game.name,
                                                                                width: 48,
                                                                                height: 48,
                                                                                className: "object-cover w-full h-full"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 508,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 507,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                                    children: game.name
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 517,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-purple-600 dark:text-purple-400 font-bold",
                                                                                    children: [
                                                                                        "R$ ",
                                                                                        game.price.toFixed(2).replace(".", ",")
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 520,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 516,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                            className: "w-4 h-4 text-gray-400 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 522,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, game.id, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 502,
                                                                    columnNumber: 23
                                                                }, this))
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 500,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            href: "/vps-gamer",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "w-full mt-4 border border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/50 bg-transparent py-2 px-4 rounded-lg font-semibold transition-all duration-300",
                                                                children: "Ver todos"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 527,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 526,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 493,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600 transition-colors group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between mb-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "text-lg font-bold group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                    children: "Próximos Títulos"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 536,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                    className: "w-5 h-5 text-purple-600 dark:text-purple-400"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 539,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 535,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-3",
                                                            children: gameCategories.upcoming.map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-3 p-2 rounded-lg",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200 dark:bg-gray-700",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                src: game.image || "/placeholder.svg",
                                                                                alt: game.name,
                                                                                width: 48,
                                                                                height: 48,
                                                                                className: "object-cover w-full h-full"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 545,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 544,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold text-gray-900 dark:text-white",
                                                                                    children: game.name
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 554,
                                                                                    columnNumber: 27
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-orange-500 font-semibold text-sm",
                                                                                    children: game.status
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 555,
                                                                                    columnNumber: 27
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 553,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                            className: "w-4 h-4 text-gray-400"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 557,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, game.id, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 543,
                                                                    columnNumber: 23
                                                                }, this))
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 541,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            className: "w-full mt-4 border border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/50 bg-transparent py-2 px-4 rounded-lg font-semibold transition-all duration-300",
                                                            children: "Notificar-me"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 561,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 534,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 450,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 447,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "mb-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl font-bold mb-6 text-gray-900 dark:text-white",
                                            children: "Jogos Novos"
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 570,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative rounded-xl overflow-hidden bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 group border border-gray-200 dark:border-gray-700",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "absolute inset-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: "/games/palworld.webp",
                                                                    alt: "Palworld",
                                                                    fill: true,
                                                                    className: "object-cover opacity-20 group-hover:opacity-30 transition-opacity"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 575,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "absolute inset-0 bg-gradient-to-r from-white/80 dark:from-gray-900/80 to-transparent"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 581,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 574,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative p-6",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "inline-block bg-gradient-to-r from-orange-500 to-red-500 text-white text-sm font-bold px-3 py-1 rounded-full mb-4",
                                                                    children: "🔥 Novo Lançamento"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 585,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                    className: "text-2xl font-bold mb-2 text-gray-900 dark:text-white",
                                                                    children: "Palworld"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 588,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mb-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-gray-500 dark:text-gray-400 line-through",
                                                                            children: "R$ 120,00"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 590,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-2xl font-bold text-gray-900 dark:text-white",
                                                                            children: "R$ 79,90"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 591,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "bg-gradient-to-r from-purple-600 to-pink-600 text-white text-sm font-bold px-2 py-1 rounded-full",
                                                                            children: "-34%"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 592,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 589,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>handleBuyNow("palworld"),
                                                                    className: "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-6 py-2 rounded-lg font-semibold transition-all duration-300 hover:scale-105",
                                                                    children: "Comprar agora"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 596,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 584,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 573,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-lg font-bold mb-4 text-gray-900 dark:text-white",
                                                            children: "Por que jogar os novos lançamentos?"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 606,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-start gap-3",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-8 h-8 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                                                                className: "w-4 h-4 text-white"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 611,
                                                                                columnNumber: 25
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 610,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold mb-1 text-gray-900 dark:text-white",
                                                                                    children: "Experiência Inovadora"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 614,
                                                                                    columnNumber: 25
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-gray-600 dark:text-gray-400 text-sm",
                                                                                    children: "Seja o primeiro a experimentar as mecânicas e gráficos de última geração."
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 615,
                                                                                    columnNumber: 25
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 613,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 609,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-start gap-3",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-8 h-8 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                                                                className: "w-4 h-4 text-white"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 623,
                                                                                columnNumber: 25
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 622,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold mb-1 text-gray-900 dark:text-white",
                                                                                    children: "Comunidade Ativa"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 626,
                                                                                    columnNumber: 25
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-gray-600 dark:text-gray-400 text-sm",
                                                                                    children: "Participe de uma comunidade vibrante e em crescimento desde o início."
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 627,
                                                                                    columnNumber: 25
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 625,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 621,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-start gap-3",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-8 h-8 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0",
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__["Gift"], {
                                                                                className: "w-4 h-4 text-white"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 635,
                                                                                columnNumber: 25
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 634,
                                                                            columnNumber: 23
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                    className: "font-semibold mb-1 text-gray-900 dark:text-white",
                                                                                    children: "Ofertas Exclusivas"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 638,
                                                                                    columnNumber: 25
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-gray-600 dark:text-gray-400 text-sm",
                                                                                    children: "Aproveite promoções e bônus especiais disponíveis apenas para novos lançamentos."
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/app/games/page.tsx",
                                                                                    lineNumber: 639,
                                                                                    columnNumber: 25
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/app/games/page.tsx",
                                                                            lineNumber: 637,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 633,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/games/page.tsx",
                                                            lineNumber: 608,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 605,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 572,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 569,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                    className: "mb-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between mb-6",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-2xl font-bold text-gray-900 dark:text-white",
                                                children: "Jogos com Descontos"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 652,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 651,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4",
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$games$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDiscountedGames"])().map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "group relative",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all duration-300 group-hover:scale-105 border border-gray-200 dark:border-gray-700 hover:border-orange-300 dark:hover:border-orange-600",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "aspect-[4/3] relative",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: game.image || "/placeholder.svg",
                                                                        alt: game.name,
                                                                        fill: true,
                                                                        className: "object-cover"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 660,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute top-2 left-2 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse",
                                                                        children: [
                                                                            "-",
                                                                            game.discount,
                                                                            "%"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 661,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "absolute inset-0 bg-gradient-to-t from-orange-100/20 dark:from-orange-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 664,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 659,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "font-semibold text-sm mb-1 truncate group-hover:text-orange-600 dark:group-hover:text-orange-400 transition-colors text-gray-900 dark:text-white",
                                                                        children: game.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 667,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-gray-400 dark:text-gray-500 line-through text-xs",
                                                                                children: [
                                                                                    "R$ ",
                                                                                    game.originalPrice?.toFixed(2).replace(".", ",")
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 671,
                                                                                columnNumber: 27
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-gray-900 dark:text-white font-bold text-sm",
                                                                                children: [
                                                                                    "R$ ",
                                                                                    game.price.toFixed(2).replace(".", ",")
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/app/games/page.tsx",
                                                                                lineNumber: 674,
                                                                                columnNumber: 27
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 670,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 666,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 658,
                                                        columnNumber: 21
                                                    }, this)
                                                }, game.id, false, {
                                                    fileName: "[project]/app/games/page.tsx",
                                                    lineNumber: 657,
                                                    columnNumber: 19
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/games/page.tsx",
                                            lineNumber: 655,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/games/page.tsx",
                                    lineNumber: 650,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/games/page.tsx",
                            lineNumber: 255,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-1",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sticky top-24 space-y-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700 backdrop-blur-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-bold mb-4 flex items-center gap-2 text-gray-900 dark:text-white",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                                                        className: "w-5 h-5 text-purple-600 dark:text-purple-400"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 692,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Jogos em destaque"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 691,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-3",
                                                children: gamesInHighlight.map((game)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        href: `/games/${game.id}`,
                                                        className: "flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors group",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "w-12 h-12 rounded-lg overflow-hidden flex-shrink-0",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: game.image || "/placeholder.svg",
                                                                    alt: game.name,
                                                                    width: 48,
                                                                    height: 48,
                                                                    className: "object-cover w-full h-full"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/games/page.tsx",
                                                                    lineNumber: 703,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 702,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex-1 min-w-0",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        className: "font-semibold truncate group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors text-gray-900 dark:text-white",
                                                                        children: game.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 712,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-purple-600 dark:text-purple-400 font-bold text-sm",
                                                                        children: [
                                                                            "R$ ",
                                                                            game.price.toFixed(2).replace(".", ",")
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/games/page.tsx",
                                                                        lineNumber: 715,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 711,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, game.id, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 697,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 695,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 690,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6 border border-gray-200 dark:border-gray-700 backdrop-blur-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-bold mb-4 text-gray-900 dark:text-white",
                                                children: "Ações Rápidas"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 726,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>window.open("https://app.neonhost.com.br/register", "_blank"),
                                                        className: "w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-2 px-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                                                                className: "w-4 h-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 732,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Criar Servidor"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 728,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>window.open("https://app.neonhost.com.br/login", "_blank"),
                                                        className: "w-full border border-purple-300 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/50 bg-transparent py-2 px-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                                className: "w-4 h-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 739,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Meus Servidores"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 735,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>window.open("https://discord.gg/neonhost", "_blank"),
                                                        className: "w-full border border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 bg-transparent py-2 px-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                                                className: "w-4 h-4"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/games/page.tsx",
                                                                lineNumber: 746,
                                                                columnNumber: 21
                                                            }, this),
                                                            "Suporte Discord"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 742,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 727,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 725,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl p-6 border border-purple-200 dark:border-purple-800 backdrop-blur-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-lg font-bold mb-2 text-gray-900 dark:text-white",
                                                children: "🔥 Ofertas Exclusivas"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 754,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-700 dark:text-gray-300 mb-4",
                                                children: "Receba descontos especiais e novidades em primeira mão!"
                                            }, void 0, false, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 755,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "email",
                                                        placeholder: "Seu melhor e-mail",
                                                        className: "w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:border-purple-500 focus:outline-none text-sm"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 757,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-2 px-4 rounded-lg font-semibold transition-all duration-300 text-sm",
                                                        children: "Inscrever-se"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/games/page.tsx",
                                                        lineNumber: 762,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/games/page.tsx",
                                                lineNumber: 756,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/games/page.tsx",
                                        lineNumber: 753,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/games/page.tsx",
                                lineNumber: 688,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/games/page.tsx",
                            lineNumber: 687,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/games/page.tsx",
                    lineNumber: 253,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/games/page.tsx",
                lineNumber: 252,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/games/page.tsx",
        lineNumber: 157,
        columnNumber: 5
    }, this);
}

})()),
"[project]/app/games/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=_689e6b._.js.map