module.exports = {

"[next]/internal/font/google/inter_59dee874.module.css [app-rsc] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "inter_59dee874-module__9CtR0q__className",
});

})()),
"[next]/internal/font/google/inter_59dee874.js [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__ = __turbopack_import__("[next]/internal/font/google/inter_59dee874.module.css [app-rsc] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__Inter_59dee8', '__Inter_Fallback_59dee8'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$module$2e$css__$5b$app$2d$rsc$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[project]/components/footer.tsx (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Footer": ()=>Footer
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const Footer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Footer() from the server but Footer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/footer.tsx", "Footer");

})()),
"[project]/components/footer.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$footer$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/footer.tsx (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$footer$2e$tsx__$28$client__proxy$29$__);

})()),
"[project]/components/navbar.tsx (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "NavbarComponent": ()=>NavbarComponent
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const NavbarComponent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call NavbarComponent() from the server but NavbarComponent is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/navbar.tsx", "NavbarComponent");

})()),
"[project]/components/navbar.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/navbar.tsx (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$28$client__proxy$29$__);

})()),
"[project]/components/promo-banner.tsx (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "PromoBanner": ()=>PromoBanner
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const PromoBanner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PromoBanner() from the server but PromoBanner is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/promo-banner.tsx", "PromoBanner");

})()),
"[project]/components/promo-banner.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$promo$2d$banner$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/promo-banner.tsx (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$promo$2d$banner$2e$tsx__$28$client__proxy$29$__);

})()),
"[project]/config/site.ts [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "siteConfig": ()=>siteConfig
});
const siteConfig = {
    name: "NeonHost",
    description: "Desbloqueie o potencial do seu projeto com a NeonHost, onde inovação e suporte personalizado se unem para impulsionar seu sucesso.",
    navItems: [
        {
            label: "Inicio",
            href: "/"
        }
    ]
};

})()),
"[project]/components/theme-provider.tsx (client proxy)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "ThemeProvider": ()=>ThemeProvider,
    "useTheme": ()=>useTheme
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const ThemeProvider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call ThemeProvider() from the server but ThemeProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/theme-provider.tsx", "ThemeProvider");
const useTheme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call useTheme() from the server but useTheme is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/components/theme-provider.tsx", "useTheme");

})()),
"[project]/components/theme-provider.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2d$provider$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/components/theme-provider.tsx (client proxy)");
"__TURBOPACK__ecmascript__hoisting__location__";
"TURBOPACK { transition: next-ecmascript-client-reference }";
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2d$provider$2e$tsx__$28$client__proxy$29$__);

})()),
"[project]/app/layout.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>RootLayout,
    "metadata": ()=>metadata,
    "viewport": ()=>viewport
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/inter_59dee874.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$footer$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/footer.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/navbar.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$promo$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/promo-banner.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/script.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2f$site$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/config/site.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/clsx/dist/clsx.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/theme-provider.tsx [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
;
;
const metadata = {
    title: {
        default: "Plataforma de servidores de jogos e VPS no Brasil | NeonHost",
        template: `%s - ${__TURBOPACK__imported__module__$5b$project$5d2f$config$2f$site$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["siteConfig"].name}`
    },
    description: "Oferecemos VPS Gamer com processadores AMD Ryzen e proteção Anti DDoS, ideais para servidores de jogos e aplicações de alto desempenho.",
    applicationName: "NeonHost",
    creator: "NeonHost",
    publisher: "NeonHost",
    authors: [
        {
            name: "NeonHost"
        }
    ],
    generator: "Next.js",
    referrer: "origin-when-cross-origin",
    robots: {
        index: true,
        follow: true,
        nosnippet: false,
        noarchive: false,
        nocache: false,
        noimageindex: false,
        googleBot: {
            index: true,
            follow: true,
            noimageindex: false,
            "max-video-preview": -1,
            "max-image-preview": "large",
            "max-snippet": -1
        }
    },
    verification: {
        google: "hsbqhlsa_EF36270POQ4hf418PvGn0QT3CcCRkw1fRE"
    },
    alternates: {
        canonical: "https://neonhost.com.br"
    },
    keywords: [
        "NeonHost",
        "BrasilFivemHost",
        "fivemhost",
        "Fivem Host",
        "bbhost",
        "BBHost",
        "BBHOST",
        "WyzeHost",
        "TynaHost",
        "Hostinger",
        "DokeHost",
        "HeavyHost",
        "OminiHost",
        "BH Servers",
        "Ultahost",
        "KnownHost",
        "Linode",
        "DigitalOcean",
        "Azure",
        "Namecheap",
        "NetEarthOne",
        "FlameHost",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "VPS Neon",
        "VPS Brasil",
        "Proteção Anti DDoS",
        "servidor de Minecraft",
        "servidor de FiveM",
        "servidor de Rust",
        "hospedagem de jogos no Brasil",
        "servidor dedicado para jogos",
        "servidor de ARK",
        "servidor de Satisfactory",
        "VPS para jogos",
        "servidores dedicados Brasil",
        "gaming VPS",
        "FiveM VPS",
        "Minecraft VPS",
        "VPS com NVMe",
        "servidor de Counter Strike",
        "servidor de CS:GO",
        "servidor de GTA RP",
        "servidor de Unturned",
        "VPS Linux",
        "VPS Windows",
        "servidor com proteção DDoS",
        "cloud gaming",
        "hospedagem de jogos multiplayer",
        "servidor dedicado gamer",
        "servidor de Minecraft Brasil",
        "VPS com alta performance",
        "VPS barato",
        "VPS para trading",
        "servidor dedicado NVMe",
        "cloud hosting",
        "FlameHost",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "wyze",
        "wyze host",
        "host",
        "ddos",
        "webhost",
        "hospedagem",
        "site",
        "vps",
        "vps gamer",
        "gaming vps",
        "vps",
        "semi dedicado",
        "servidor dedicado",
        "teamspeak",
        "team-speak",
        "team-speak 3 server",
        "proteção ddos",
        "server",
        "servidor",
        "servidor",
        "serviço de hospedagem",
        "hospedagem brasil",
        "host brasileira",
        "host 0ms",
        "melhor host do brasil",
        "onde hospedar",
        "como hospedar um site",
        "como hospedar um site",
        "como hospedar fivem",
        "host de jogo",
        "vrising",
        "como criar servidor de vrising",
        "como criar servidor de gta rp",
        "como criar servidor de fivem",
        "como criar servidor de cidade fivem",
        "como criar servidor de cidade fivem rp",
        "jogar vrising online",
        "vrising online",
        "melhor servidor vrising",
        "vrising server",
        "host fivem",
        "hospedagem de fivem",
        "fivem",
        "host minecraft",
        "hospedagem minecraft",
        "minecraft",
        "como deixar fivem online 24 horas",
        "criar cidade fivem",
        "cidade",
        "host de fivem",
        "host gta rp",
        "hospedagem para gta rp",
        "host fivem br",
        "fivem host",
        "ddos",
        "proteção ddos",
        "anti-ddos",
        "Hostzone",
        "Hostinger",
        "HeavyHost",
        "BH Servers",
        "Ultahost",
        "KnownHost",
        "Linode",
        "DigitalOcean",
        "Azure",
        "Namecheap",
        "NetEarthOne",
        "FlameHost",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "VPS Neon",
        "VPS Brasil",
        "Proteção Anti DDoS",
        "servidor de Minecraft",
        "servidor de FiveM",
        "servidor de Rust",
        "hospedagem de jogos no Brasil",
        "servidor dedicado para jogos",
        "servidor de ARK",
        "servidor de Satisfactory",
        "VPS para jogos",
        "servidores dedicados Brasil",
        "gaming VPS",
        "FiveM VPS",
        "Minecraft VPS",
        "VPS com NVMe",
        "servidor de Counter Strike",
        "servidor de CS:GO",
        "servidor de GTA RP",
        "servidor de Unturned",
        "VPS Linux",
        "VPS Windows",
        "servidor com proteção DDoS",
        "cloud gaming",
        "hospedagem de jogos multiplayer",
        "servidor dedicado gamer",
        "servidor de Minecraft Brasil",
        "VPS com alta performance",
        "VPS barato",
        "VPS para trading",
        "servidor dedicado NVMe",
        "cloud hosting",
        "cache externo",
        "cache externo fivem",
        "cache externo gtarp",
        "cache-externo",
        "cache-externo fivem",
        "cache-externo gtarp",
        "cache-externo vps",
        "cache-externo vps gamer",
        "cache externo vps",
        "cache externo vps gamer",
        "cache externo redm",
        "cache externo rd2",
        "host de redm",
        "vps redm",
        "vps rd2",
        "Vps Redm",
        "Vps Gamer",
        "Vps gamer",
        "vps gamer",
        "Servidor VPS Gamer",
        "Servidor Vps Gamer",
        "Servidor Gamer",
        "Steam",
        "Steam Games",
        "Steam VPS",
        "VPS Azure",
        "Google Cloud",
        "vps barato",
        "comprar vps",
        "servidor vps brasil",
        "vps windows barato",
        "melhor vps 2025",
        "vps vs dedicado",
        "vps cloud brasil",
        "vps são paulo",
        "vps rio de janeiro",
        "datacenter brasil",
        "hospedagem servidor minecraft",
        "servidor minecraft barato",
        "free minecraft server hosting",
        "hospedagem fivem",
        "vps fivem ddos",
        "servidor gta rp host",
        "servidor rust brasil",
        "ark server hosting",
        "valheim server brasileiro",
        "game server hosting",
        "low latency vps",
        "ddos protection gamer",
        "como criar servidor minecraft 24/7 vps",
        "vps linux para jogos com painel pterodactyl",
        "vps gamer com proteção ddos grátis",
        "comprar vps barato com ping baixo brasil",
        "vps fivem barato",
        "hospedagem fivem ddos",
        "vps para gta rp",
        "vps redm brasil",
        "vps para redm brasil",
        "vps para redm",
        "servidor gta rp host",
        "hospedar servidor redm",
        "como criar servidor fivem com vps",
        "melhor vps para fivem 2025",
        "vps com proteção ddos para gta rp",
        "hospedagem redm com painel txadmin",
        "vps fivem ping baixo brasil",
        "top 10 melhores host fivem",
        "top 10 melhores vps gamer",
        "As top 10 melhores vps gamer",
        "As top 10 melhores vps fivem",
        "As top 10 melhores host fivem",
        "NeonHost",
        "WyzeHost",
        "TynaHost",
        "Hostinger",
        "DokeHost",
        "HeavyHost",
        "OminiHost",
        "BH Servers",
        "Ultahost",
        "KnownHost",
        "Linode",
        "DigitalOcean",
        "Azure",
        "Namecheap",
        "NetEarthOne",
        "FlameHost",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "VPS Gamer",
        "VPS Brasil",
        "Proteção Anti DDoS",
        "servidor de Minecraft",
        "servidor de FiveM",
        "servidor de Rust",
        "hospedagem de jogos no Brasil",
        "servidor dedicado para jogos",
        "servidor de ARK",
        "servidor de Satisfactory",
        "VPS para jogos",
        "servidores dedicados Brasil",
        "gaming VPS",
        "FiveM VPS",
        "Minecraft VPS",
        "VPS com NVMe",
        "servidor de Counter Strike",
        "servidor de CS:GO",
        "servidor de GTA RP",
        "servidor de Unturned",
        "VPS Linux",
        "VPS Windows",
        "servidor com proteção DDoS",
        "cloud gaming",
        "hospedagem de jogos multiplayer",
        "servidor dedicado gamer",
        "servidor de Minecraft Brasil",
        "VPS com alta performance",
        "VPS barato",
        "VPS para trading",
        "servidor dedicado NVMe",
        "cloud hosting",
        "FlameHost",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "Hostzone",
        "Hostinger",
        "HeavyHost",
        "BH Servers",
        "Ultahost",
        "KnownHost",
        "Linode",
        "DigitalOcean",
        "Azure",
        "Namecheap",
        "NetEarthOne",
        "FlameHost",
        "fivem",
        "Fivem",
        "Fivem VPS",
        "Melhores VPS Fivem",
        "Melhores VPS FiveM",
        "Melhores VPS FiveM Brasil",
        "Melhores VPS FiveM Brasil 2024",
        "Melhores VPS FiveM Brasil 2025",
        "Melhores VPS Gamer",
        "Melhores VPS Gamer Brasil",
        "Melhores VPS Gamer Brasil 2024",
        "Melhores VPS Gamer Brasil 2025",
        "Melhores VPS 2024",
        "Melhores VPS 2025",
        "Melhores VPS Brasil",
        "NeonHost",
        "Neonhost",
        "Servidores Dedicados",
        "Servidores Dedicados Brasil",
        "Servidores Dedicados Brasil 2024",
        "Servidores Dedicados Brasil 2025",
        "Host Rust",
        "Host Rust Brasil",
        "Host Rust Brasil 2024",
        "Host Rust Brasil 2025",
        "Host Terraria",
        "Host Terraria Brasil",
        "Host Terraria Brasil 2024",
        "Host Terraria Brasil 2025",
        "Host Minecraft",
        "Host Minecraft Brasil",
        "Host Minecraft Brasil 2024",
        "Host Minecraft Brasil 2025",
        "vps",
        "vps gamer",
        "vps gamer Brasil",
        "vps gamer Brasil 2024",
        "vps gamer Brasil 2025",
        "fivem brasil",
        "fivem brasil 2024",
        "fivem brasil 2025",
        "fivem host",
        "fivem host Brasil",
        "fivem host Brasil 2024",
        "fivem host Brasil 2025",
        "vps para fivem",
        "vps para fivem Brasil",
        "vps para jogos",
        "vps para jogos Brasil",
        "vps para jogos Brasil 2024",
        "host para dayz",
        "host para dayz Brasil",
        "host para dayz Brasil 2024",
        "host para dayz Brasil 2025",
        "cloud vps",
        "cloud vps Brasil",
        "cloud vps Brasil 2024",
        "cloud vps Brasil 2025",
        "cloud vps gamer",
        "cloud vps gamer Brasil",
        "cloud vps gamer Brasil 2024",
        "cloud vps gamer Brasil 2025",
        "host para ragnarok",
        "host para ragnarok Brasil",
        "host para ragnarok Brasil 2024",
        "host para ragnarok Brasil 2025",
        "bbhost",
        "bbhost",
        "bb host",
        "host",
        "host de jogos",
        "host de jogos Brasil",
        "host de jogos Brasil 2024",
        "host de jogos Brasil 2025",
        "host para jogos",
        "host para jogos Brasil",
        "host para jogos Brasil 2024",
        "fivem host brasil",
        "fivem host brasil 2024",
        "fivem host brasil 2025",
        "host fivembrasil",
        "fivem host",
        "fivem brasil host",
        "host para ark",
        "vps",
        "vps brasil",
        "vps no brasil",
        "vps gamer",
        "servidores",
        "servidores vps",
        "servidores vps brasil",
        "vps barata",
        "vps windows",
        "vps linux",
        "virtual maquina",
        "virtual maquina brasil",
        "virtual maquina brasil 2024",
        "virtual maquina brasil 2025",
        "anti ddos",
        "anti ddos brasil",
        "anti ddos brasil 2024",
        "anti ddos brasil 2025",
        "antiddos",
        "anti-ddos",
        "melhor protecao para fivem",
        "melhor protecao para fivem brasil",
        "melhor protecao para fivem brasil 2024",
        "melhor protecao para fivem brasil 2025",
        "fivem",
        "fivem brasil",
        "gta v host",
        "gta host",
        "gta host brasil",
        "gta host brasil 2024",
        "gta host brasil 2025",
        "mta",
        "mta brasil",
        "mta brasil 2024",
        "mta brasil 2025",
        "servidores dedicados",
        "dedicado",
        "dedicados",
        "baremetal",
        "baremetal brasil",
        "baremetal brasil 2024",
        "baremetal brasil 2025",
        "datacenter br",
        "datacenter brasil",
        "datacenter brasil 2024",
        "datacenter brasil 2025",
        "brasil",
        "o que é vps",
        "RazeHost",
        "Loding Hosting",
        "Nice Hosting",
        "VPS Gamer",
        "VPS Brasil",
        "Proteção Anti DDoS",
        "servidor de Minecraft",
        "servidor de FiveM",
        "servidor de Rust",
        "hospedagem de jogos no Brasil",
        "servidor dedicado para jogos",
        "servidor de ARK",
        "servidor de Satisfactory",
        "VPS para jogos",
        "servidores dedicados Brasil",
        "gaming VPS",
        "FiveM VPS",
        "Minecraft VPS",
        "VPS com NVMe",
        "servidor de Counter Strike",
        "servidor de CS:GO",
        "servidor de GTA RP",
        "servidor de Unturned",
        "VPS Linux",
        "VPS Windows",
        "servidor com proteção DDoS",
        "cloud gaming",
        "hospedagem de jogos multiplayer",
        "servidor dedicado gamer",
        "servidor de Minecraft Brasil",
        "VPS com alta performance",
        "VPS barato",
        "VPS para trading",
        "servidor dedicado NVMe",
        "cloud hosting",
        "cache externo",
        "cache externo fivem",
        "cache externo gtarp",
        "cache-externo",
        "cache-externo fivem",
        "cache-externo gtarp",
        "cache-externo vps",
        "cache-externo vps gamer",
        "cache externo vps",
        "cache externo vps gamer",
        "vps",
        "TacoHost",
        "Neopixelhost"
    ],
    openGraph: {
        title: "Hospedagem de Jogos no Brasil | NeonHost",
        description: "Hospedagem de alto desempenho, com baixa latência, infraestrutura no Brasil, armazenamento NVMe e proteção anti-DDoS para jogos como Minecraft, FiveM e muito mais.",
        url: "https://neonhost.com.br/",
        siteName: "NeonHost",
        locale: "pt_BR",
        type: "website",
        images: [
            {
                url: "https://neonhost.com.br/NeonHost.png",
                width: 1280,
                height: 630,
                alt: "NeonHost - Hospedagem de Jogos no Brasil"
            }
        ]
    },
    twitter: {
        card: "summary_large_image",
        title: "Hospedagem de Jogos no Brasil | NeonHost",
        description: "Desempenho superior e segurança com infraestrutura no Brasil. Hospede seus servidores de Minecraft, FiveM e outros jogos com proteção Anti DDoS.",
        site: "@neonhost",
        creator: "@neonhost",
        images: [
            {
                url: "https://neonhost.com.br/NeonHost.png",
                width: 1280,
                height: 630,
                alt: "NeonHost - Hospedagem de Jogos no Brasil"
            }
        ]
    },
    icons: {
        icon: "/favicon.ico"
    }
};
const viewport = {
    themeColor: [
        {
            media: "(prefers-color-scheme: light)",
            color: "white"
        },
        {
            media: "(prefers-color-scheme: dark)",
            color: "black"
        }
    ]
};
async function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "pt-BR",
        suppressHydrationWarning: true,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("head", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        id: "gtm-script",
                        strategy: "afterInteractive",
                        dangerouslySetInnerHTML: {
                            __html: `
                        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                        })(window,document,'script','dataLayer','GTM-NLK4RWTG');
                    `
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 588,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                        type: "application/ld+json",
                        dangerouslySetInnerHTML: {
                            __html: JSON.stringify({
                                "@context": "https://schema.org",
                                "@type": "Organization",
                                name: "NeonHost",
                                url: "https://neonhost.com.br",
                                description: "Hospedagem de jogos no Brasil com VPS Gamer, proteção Anti-DDoS e infraestrutura de alta performance",
                                address: {
                                    "@type": "PostalAddress",
                                    addressCountry: "BR",
                                    addressRegion: "SP",
                                    addressLocality: "São Paulo"
                                },
                                contactPoint: {
                                    "@type": "ContactPoint",
                                    telephone: "+55 24 99243-0751",
                                    contactType: "customer service",
                                    availableLanguage: "Portuguese"
                                },
                                sameAs: [
                                    "https://twitter.com/neonhost",
                                    "https://facebook.com/neonhost",
                                    "https://instagram.com/neonhost"
                                ],
                                offers: [
                                    {
                                        "@type": "Offer",
                                        name: "VPS Gamer",
                                        description: "VPS de alta performance com proteção Anti-DDoS",
                                        price: "72.90",
                                        priceCurrency: "BRL",
                                        availability: "https://schema.org/InStock"
                                    },
                                    {
                                        "@type": "Offer",
                                        name: "VPS Streaming",
                                        description: "Servidores com tráfego ilimitado",
                                        price: "249.90",
                                        priceCurrency: "BRL",
                                        availability: "https://schema.org/InStock"
                                    }
                                ]
                            })
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 601,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "google-site-verification",
                        content: "hsbqhlsa_EF36270POQ4hf418PvGn0QT3CcCRkw1fRE"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 645,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "author",
                        content: "NeonHost"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 646,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "geo.region",
                        content: "BR-SP"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 647,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "geo.placename",
                        content: "São Paulo, Brasil"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 648,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "language",
                        content: "pt-BR"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 649,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "rating",
                        content: "general"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 650,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("meta", {
                        name: "distribution",
                        content: "global"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 651,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("link", {
                        rel: "canonical",
                        href: "https://neonhost.com.br/"
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 652,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 587,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])("min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100", __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_59dee874$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"].className),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "snow-container",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 656,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 657,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 658,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 659,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 660,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 661,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 662,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 663,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 664,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "snowflake"
                            }, void 0, false, {
                                fileName: "[project]/app/layout.tsx",
                                lineNumber: 665,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 655,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2d$provider$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ThemeProvider"], {
                        defaultTheme: "light",
                        storageKey: "neonhost-theme",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative flex flex-col",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$promo$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PromoBanner"], {}, void 0, false, {
                                    fileName: "[project]/app/layout.tsx",
                                    lineNumber: 669,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "pt-[40px]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "border-b border-gray-200 dark:border-b-gray-700",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$navbar$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NavbarComponent"], {}, void 0, false, {
                                                fileName: "[project]/app/layout.tsx",
                                                lineNumber: 672,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 671,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                                            className: "bg-gray-50 dark:bg-[#0A0C10]",
                                            children: children
                                        }, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 674,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$footer$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Footer"], {}, void 0, false, {
                                            fileName: "[project]/app/layout.tsx",
                                            lineNumber: 675,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/layout.tsx",
                                    lineNumber: 670,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/layout.tsx",
                            lineNumber: 668,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/layout.tsx",
                        lineNumber: 667,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 654,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/layout.tsx",
        lineNumber: 586,
        columnNumber: 5
    }, this);
}

})()),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    default: () => __turbopack_import__("[project]/app/layout.tsx [app-rsc] (ecmascript)"),
});

})()),
"[project]/app/redes/page.tsx [app-rsc] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>Page
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$redes$2d$page$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/components/redes-page.tsx [app-rsc] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
function Page() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$redes$2d$page$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/app/redes/page.tsx",
        lineNumber: 4,
        columnNumber: 10
    }, this);
}

})()),
"[project]/app/redes/page.tsx [app-rsc] (ecmascript, Next.js server component)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_esm__({
    default: () => __turbopack_import__("[project]/app/redes/page.tsx [app-rsc] (ecmascript)"),
});

})()),
"[project]/.next-internal/server/app/redes/page/actions.js [app-rsc] (ecmascript)": (function({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require }) { !function() {

__turbopack_export_value__({});

}.call(this) }),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__d9b234._.js.map