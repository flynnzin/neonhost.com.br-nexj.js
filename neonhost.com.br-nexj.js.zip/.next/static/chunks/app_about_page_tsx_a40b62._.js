(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_about_page_tsx_a40b62._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_about_page_tsx_a40b62._.js",
  "chunks": [
    "static/chunks/_96517b._.js",
    "static/chunks/node_modules_f94b2f._.js"
  ],
  "source": "dynamic"
});
