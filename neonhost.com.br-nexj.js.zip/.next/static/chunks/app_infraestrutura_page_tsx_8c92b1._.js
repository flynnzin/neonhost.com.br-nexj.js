(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_infraestrutura_page_tsx_8c92b1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_infraestrutura_page_tsx_8c92b1._.js",
  "chunks": [
    "static/chunks/_bdf2b3._.js"
  ],
  "source": "dynamic"
});
