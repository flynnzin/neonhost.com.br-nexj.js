(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[404]_layout_tsx_68cf0a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[404]_layout_tsx_68cf0a._.js",
  "chunks": [
    "static/chunks/app_[404]_layout_tsx_31f44b._.js"
  ],
  "source": "dynamic"
});
