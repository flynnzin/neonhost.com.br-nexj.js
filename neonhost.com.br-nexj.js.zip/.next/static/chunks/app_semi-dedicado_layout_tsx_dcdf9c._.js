(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_semi-dedicado_layout_tsx_dcdf9c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_semi-dedicado_layout_tsx_dcdf9c._.js",
  "chunks": [
    "static/chunks/app_semi-dedicado_layout_tsx_10dd94._.js"
  ],
  "source": "dynamic"
});
