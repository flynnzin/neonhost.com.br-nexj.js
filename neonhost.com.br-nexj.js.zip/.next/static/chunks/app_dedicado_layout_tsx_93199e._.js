(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dedicado_layout_tsx_93199e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dedicado_layout_tsx_93199e._.js",
  "chunks": [
    "static/chunks/app_dedicado_layout_tsx_edcf5a._.js"
  ],
  "source": "dynamic"
});
