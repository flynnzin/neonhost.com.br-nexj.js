(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dedicado_page_tsx_0b64e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dedicado_page_tsx_0b64e1._.js",
  "chunks": [
    "static/chunks/node_modules_3b4fee._.js",
    "static/chunks/app_dedicado_page_tsx_1010c4._.js"
  ],
  "source": "dynamic"
});
