(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_semi-dedicado_page_tsx_e471bf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_semi-dedicado_page_tsx_e471bf._.js",
  "chunks": [
    "static/chunks/_a9afab._.js"
  ],
  "source": "dynamic"
});
