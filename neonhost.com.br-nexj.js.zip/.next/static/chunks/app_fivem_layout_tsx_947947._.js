(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_fivem_layout_tsx_947947._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_fivem_layout_tsx_947947._.js",
  "chunks": [
    "static/chunks/app_fivem_layout_tsx_92ac60._.js"
  ],
  "source": "dynamic"
});
