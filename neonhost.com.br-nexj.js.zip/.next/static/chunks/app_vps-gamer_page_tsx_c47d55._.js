(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_vps-gamer_page_tsx_c47d55._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_vps-gamer_page_tsx_c47d55._.js",
  "chunks": [
    "static/chunks/_bfc86d._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_e6d617._.js"
  ],
  "source": "dynamic"
});
