(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_infraestrutura_page_tsx_6a769b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_infraestrutura_page_tsx_6a769b._.js",
  "chunks": [
    "static/chunks/_ecbb15._.js"
  ],
  "source": "dynamic"
});
