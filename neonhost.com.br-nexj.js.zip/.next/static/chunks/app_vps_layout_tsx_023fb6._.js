(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_vps_layout_tsx_023fb6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_vps_layout_tsx_023fb6._.js",
  "chunks": [
    "static/chunks/app_vps_layout_tsx_83e76f._.js"
  ],
  "source": "dynamic"
});
