(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_about_page_tsx_4038cc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_about_page_tsx_4038cc._.js",
  "chunks": [
    "static/chunks/_96517b._.js",
    "static/chunks/node_modules_ca0b96._.js"
  ],
  "source": "dynamic"
});
