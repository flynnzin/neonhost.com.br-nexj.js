(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[404]_page_tsx_ecbb1b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[404]_page_tsx_ecbb1b._.js",
  "chunks": [
    "static/chunks/app_[404]_page_tsx_910d18._.js"
  ],
  "source": "dynamic"
});
