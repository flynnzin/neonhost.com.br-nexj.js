(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_c80747._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_c80747._.js",
  "chunks": [
    "static/chunks/[root of the server]__ef8e25._.css",
    "static/chunks/_ee4a6f._.js",
    "static/chunks/node_modules_next_0e864b._.js",
    "static/chunks/node_modules_motion-dom_dist_es_ed5d78._.js",
    "static/chunks/node_modules_framer-motion_dist_es_5f3643._.js",
    "static/chunks/node_modules_@nextui-org_e5eb64._.js",
    "static/chunks/node_modules_d877a3._.js",
    "static/chunks/node_modules_995dbd._.js",
    "static/chunks/node_modules_e75216._.js",
    "static/chunks/node_modules_tailwind-merge_dist_lib_40ffc2._.js",
    "static/chunks/node_modules_2a39c6._.js",
    "static/chunks/node_modules_react-icons_bi_index_mjs_cba0e8._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_ca6b27._.js",
    "static/chunks/node_modules_@nextui-org_dom-animation_dist_index_mjs_99e2c5._.js"
  ],
  "source": "dynamic"
});
