(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_anti-ddos_page_tsx_114c4b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_anti-ddos_page_tsx_114c4b._.js",
  "chunks": [
    "static/chunks/_931a87._.js"
  ],
  "source": "dynamic"
});
