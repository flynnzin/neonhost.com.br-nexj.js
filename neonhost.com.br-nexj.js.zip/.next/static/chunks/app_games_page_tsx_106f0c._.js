(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_games_page_tsx_106f0c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_games_page_tsx_106f0c._.js",
  "chunks": [
    "static/chunks/_542ae9._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_65eba1._.js"
  ],
  "source": "dynamic"
});
