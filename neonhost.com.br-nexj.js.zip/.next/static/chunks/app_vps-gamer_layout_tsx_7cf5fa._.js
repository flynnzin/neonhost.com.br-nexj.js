(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_vps-gamer_layout_tsx_7cf5fa._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_vps-gamer_layout_tsx_7cf5fa._.js",
  "chunks": [
    "static/chunks/app_vps-gamer_layout_tsx_cdc66d._.js"
  ],
  "source": "dynamic"
});
