(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_redes_page_tsx_8964f6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_redes_page_tsx_8964f6._.js",
  "chunks": [
    "static/chunks/_4315ad._.js"
  ],
  "source": "dynamic"
});
