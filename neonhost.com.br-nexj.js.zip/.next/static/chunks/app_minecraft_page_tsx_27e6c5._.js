(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_minecraft_page_tsx_27e6c5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_minecraft_page_tsx_27e6c5._.js",
  "chunks": [
    "static/chunks/app_minecraft_bbdd3b._.js",
    "static/chunks/node_modules_lucide-react_dist_esm_icons_4a7fcc._.js"
  ],
  "source": "dynamic"
});
