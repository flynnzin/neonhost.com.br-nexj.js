(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_vps-flex_layout_tsx_166561._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_vps-flex_layout_tsx_166561._.js",
  "chunks": [
    "static/chunks/app_vps-flex_layout_tsx_ebaee1._.js"
  ],
  "source": "dynamic"
});
